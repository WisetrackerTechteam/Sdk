//
//  FaceBookWrapper.h
//  WiseTracker
//
//  Created by janginha on 2015. 9. 24..
//  Copyright © 2015년 WiseTracker. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h> 

@interface FaceBookWrapper : NSObject

+(BOOL) getFlagOfFacebookIntegration;
+(void) setFlagOfFacebookIntegration:(BOOL)newVal;

+(void)facebookInit:(UIApplication*)application WithOptions:(NSDictionary *)launchOptions;
//+(void)initFacebookSdkReferrer:(NSDictionary *)launchOptions;
+(void)initFacebookSdkReferrer:(NSDictionary *)launchOptions;
+(void)activateApp;

@end
